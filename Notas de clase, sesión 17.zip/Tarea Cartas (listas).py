# -*- coding: utf-8 -*-
"""
Created on Sun Nov 26 18:08:49 2017

@author: Ricardo
"""

from Tkinter import *
import numpy as np

class DeckOfCards:
    def __init__(self):
        
        window = Tk()
        window.title("Cartas")
        frame = Frame(window)
        frame2 = Frame(window)
        
        self.imageList = []
        
        # Las imágenes de cartas las he llamado con un número del 01 al 54
        # (incluyendi Jokers). En las siguietnes líneas, las agrego a una lista.
        
        for i in range(1, 55):
            if i < 10:
                self.cardImg = PhotoImage(file = "cards/0" + str(i) + ".gif")
            else:
                self.cardImg = PhotoImage(file = "cards/" + str(i) + ".gif")
            
            self.imageList.append(self.cardImg)
                                     
        self.labelList = []
        
        for i in range(4):
            self.labelList.append(Label(frame, image = self.imageList[i]))
            self.labelList[i].pack(side = LEFT)
        
        # Aparte del botón de barajar, he puesto dos botones para incluir o
        # descartar los Jokers.
        
        Button(window, text = "Barajar", command = self.shuffle).pack()
        quitarBt = Button(frame2, text = "Quitar Jokers", command = self.removeJokers, bg = "red")
        incluirBt = Button(frame2, text = "Incluir Jokers", command = self.includeJokers, bg = "green")
        
        quitarBt.pack()
        incluirBt.pack()
        quitarBt.grid(row = 2, column = 2)
        incluirBt.grid(row = 2, column = 1)
                    
        frame.pack()
        frame2.pack()
        
        window.mainloop()
    
    # Al oprimir el botón barajar, se activa la función shuffle, que utiliza
    # el shuffle de numpy.random para desordenar aleatoriamente la lista de imágenes.
    # Luego, se muestra en pantalla las cuatro primeras imágenes de la lista.
    
    def shuffle(self):
        np.random.shuffle(self.imageList)
        for i in range(4):
            self.labelList[i]["image"] = self.imageList[i]
            
    # Los botones de quitar o incluir Jokers activan las siguientes dos funciones.
    # Lo que hacen es crear desde cero nuevas listas, ya sea incluyendo o
    # excluyendo los Jokers de esta.
    
    def removeJokers(self):
        self.imageList = []
        
        for i in range(1, 53):
            if i < 10:
                self.cardImg = PhotoImage(file = "cards/0" + str(i) + ".gif")
            else:
                self.cardImg = PhotoImage(file = "cards/" + str(i) + ".gif")
            
            self.imageList.append(self.cardImg)
    
    def includeJokers(self):
        self.imageList = []
        
        for i in range(1, 55):
            if i < 10:
                self.cardImg = PhotoImage(file = "cards/0" + str(i) + ".gif")
            else:
                self.cardImg = PhotoImage(file = "cards/" + str(i) + ".gif")
            
            self.imageList.append(self.cardImg)
    
DeckOfCards()